export const mcqData = [
    {
        questionId : 1,
        questionTitle : "This is first qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : true
    },
    {
        questionId : 2,
        questionTitle : "This is second qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 3,
        questionTitle : "This is third qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 4,
        questionTitle : "This is fourth qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 5,
        questionTitle : "This is fifth qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 6,
        questionTitle : "This is sixth qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 7,
        questionTitle : "This is seventh qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 8,
        questionTitle : "This is eight qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 9,
        questionTitle : "This is ninth qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    },
    {
        questionId : 10,
        questionTitle : "This is tenth qeustion",
        responseSet : [
            "yes",
            "no",
            "maybe",
            "both"
        ],
        isShow : false
    }
]