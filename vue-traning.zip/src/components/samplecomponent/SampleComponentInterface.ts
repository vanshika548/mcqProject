export interface SampeViewComponent {
      privateMethod: (firstValue:number,secondValue:number) => number;
      showUserPosts() : void;
}