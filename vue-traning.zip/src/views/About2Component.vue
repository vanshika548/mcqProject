<template>
   <div class="about">
     
    <h1>Second view content</h1>
  </div>
</template>

<script lang="ts">
// @ is an alias to /src
export default {
  name : 'About2Component'
};
</script>
