let config = {
    language:'en',
    userrole:'admin',
    user_email:"user@useremail.com",
    environment:'dev',
    VUE_API_BASE_URL : "https://jsonplaceholder.typicode.com"
}

export default config;